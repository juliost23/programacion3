var numero = 34;
console.log(numero);


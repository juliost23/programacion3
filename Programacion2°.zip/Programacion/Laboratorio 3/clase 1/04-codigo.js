var algo = "manzana"

switch (algo) {
    
    case "manzana":
    case "banana":
    case "pera":
        console.log("es una fruta")
        break;
    case "lechuga":
    case "cebolla":
    case "papa":
        console.log("es una verdura");
        break;
    default:
        console.log("no se que es");

}
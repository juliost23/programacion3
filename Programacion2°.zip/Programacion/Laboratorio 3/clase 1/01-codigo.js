// IF

var a = 2;

if (a%2 == 0) {
    //verdadero
    console.log(" a es par");
} else {
    //falso
    console.log("a es impar");
}


var numero1 = 34;
var numero2 = "34";

if (numero1 === numero2) {
    console.log("Verdadero");
} else {
    console.log("Falso");
}





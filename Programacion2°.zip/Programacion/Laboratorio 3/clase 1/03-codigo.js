var mes = 1;
/*
if (mes==1 ) 
{
    console.log("enero");
}
else if (mes==2)
{
    console.log("febrero");
}
else if (mes==3) 
{
    console.log("marzo");
}
*/
switch (mes) {
    case 1:
        console.log("enero");
        break;
    case 2:
        console.log("febrero");
        break;
    case 3:
        console.log("marzo");
        break;
    default:
        console.log("mes fuera de rango");

}
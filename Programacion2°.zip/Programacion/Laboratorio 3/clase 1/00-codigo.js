//mostrar texto

console.log("Hola mundo");

//mostrar numero

console.log(23);

/* 
concatenar texto + numero
*/

console.log("numero: "+ 23);


// variables 
var texto = "texto";
var numero = 23.5; 
var bool = true;

console.log(bool);

var numero2 = "22";
console.log(numero2);
console.log(+numero2);

console.log(typeof texto);
texto=45;                     //cambio el tipo de variable de texto.. pasa de string a number
console.log(typeof texto);


console.log(typeof numero);
console.log(typeof bool);

var variable2
console.log(typeof variable2);

var variable3 = null
console.log(typeof variable3);